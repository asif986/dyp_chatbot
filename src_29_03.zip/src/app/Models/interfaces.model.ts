export interface userData {
    token: string,
    user: {

        created_at: null,
        email: string,
        email_verified_at: null,
        id: number,
        name: string,
        role:number,
        updated_at: null,
        office_id: number

    }
}