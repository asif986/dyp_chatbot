import { HttpClient } from '@angular/common/http';
import { Component, OnInit, ViewChild } from '@angular/core';
import { AlertController, IonContent, LoadingController } from '@ionic/angular';
import { AuthService } from 'src/app/services/auth.service';
import { environment } from 'src/environments/environment';

@Component({
  selector: 'app-conversation',
  templateUrl: './conversation.page.html',
  styleUrls: ['./conversation.page.scss'],
})
export class ConversationPage implements OnInit {
  newmsg='';
  @ViewChild(IonContent) content :IonContent;
  messages =[] ;
  butttons = [];
  localhostIP = environment.localhostIP;
    constructor(public authservice:AuthService,public httpclient:HttpClient,public loadingctr:LoadingController,public alterctrl:AlertController) { }
    
    ngOnInit() {
      console.log(this.messages)
      let body = 
{
  msg:"welcome"
}
console.log(body)
let currentDate=new Date();
    this.httpclient.post(this.localhostIP,body) .subscribe((data:any)=>
    {
      console.log(typeof(data))
      console.log(data.res)
      this.messages.push({
        user:'bot',
        createAt:new Date(),
        msg:data.res   
      });
      console.log(JSON.stringify(data))
    },error=>
    {
      console.log(error)
    })


    }


    sendmsg(param?:string)
  {
let body = 
{
  msg:param===undefined?this.newmsg:param
}

console.log(param)
console.log(body)
let currentDate=new Date();
    this.httpclient.post('http://localhost:5000/',body) .subscribe((data:any)=>
    {
      
      //let test = (data.res).substring((data.res).lastIndexOf("\n") + 1, -4 );
//       let test2 = (data.res).split('\n');
// // remove one line, starting at the first position
// test2.splice(0,1);
// //console.log(test);
// console.log(test2)
// join the array back into a single string
// let newtext = test2.join('\n');
//       console.log(newtext);
//substring created from * to bottom of msg + 1 because string start with 0

let mainstring ;
console.log((data.res).includes("*"));
if((data.res).includes("*"))
{
  console.log()

  mainstring = (data.res).substring(0,(data.res).indexOf("*")-1);
}else
{
  mainstring = (data.res);
}
console.log(mainstring)


//substring created from * to bottom of msg + 2 because * +' '+' ' means empty space two times
      let options =       (data.res).substring((data.res).indexOf("*") + 2);
     let t =  options.split('\n');
     this.butttons = t;

     //console.log(Object.keys(t.full))
      console.log(options)
      this.messages.push({
        user:'bot',
        createAt:new Date(),
        msg:mainstring  

      });
      console.log(JSON.stringify(data))
      setTimeout(() => {
    
        this.content.scrollToBottom(400);
      }, 500);
    },error=>
    {
      console.log(error)
    })


this.messages.push(
  {
    user:'harsh',
    createAt:new Date(),
    msg:body.msg
  })
  this.newmsg='';

  }
  async logout()
  {
    const loading = await this.loadingctr.create({message:"Please wait..",duration:2000});
const alert = await this.alterctrl.create({message:"Thank you for using Our DYPChatBot!!!",buttons:[{text:"Ok",role:'Ok'}]})
 
    loading.present();
    await this.authservice.logout().then(res=>
      {
        console.log(res)
        setTimeout(() => {
          
          loading.dismiss()
          alert.present();
        }, 2000);
      });
  }

  public dynamicCol()

  {
    let row ;
    if(this.butttons.length==8)
    {
      row = 3;
    }
    console.log(this.butttons.length);
    return row;
  }
}
