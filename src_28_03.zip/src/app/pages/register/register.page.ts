import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { AlertController, LoadingController, ToastController } from '@ionic/angular';
import { AngularFireAuth } from  "@angular/fire/auth";
import { ApiAiClient } from 'api-ai-javascript/es6/ApiAiClient'

import{environment} from '../../../environments/environment';
import { AuthService } from 'src/app/services/auth.service';
@Component({
  selector: 'app-register',
  templateUrl: './register.page.html',
  styleUrls: ['./register.page.scss'],
})
export class RegisterPage implements OnInit {
  name:string="Harsh";
  email:string="harsh@gmail.com";
  password:string="123456";
  confirm:string="123456";
  //readonly token = environment.dialogflow.angularBot;
  //readonly client = new ApiAiClient({ accessToken: this.token });

  constructor(public alterctrl:AlertController,public loadingctr:LoadingController,public authservice:AuthService,public alertController: AlertController,public tostctrl:ToastController) { }

  ngOnInit() {
   // this.client.textRequest("text").then(res=>{console.log(res)})
  }
  async register(form:NgForm)
  {
    const loading = await this.loadingctr.create({message:"Please wait..",duration:2000});
    loading.present();
    const alert = await this.alterctrl.create({message:"WelCome To DYPChatBot!!!",buttons:[{text:"Ok",role:'Ok'}]})
    console.log(form.form.value) 
    if(form.form.value!=='')
    {
      this.authservice.register(this.email,this.password).then(res=>
        {
          console.log(res);
          setTimeout(() => {
            loading.dismiss()
            alert.present();
          }, 2000);
    
        },async(error)=>
        {
          const toast = await this.tostctrl.create({message:error.message,duration:2000})
          toast.present();
          console.log(error.message)
        })
        console.log(this.email) 
      }else
      {
     const toast = await this.tostctrl.create({message:"Please Enter details",duration:2000})
     toast.present();

   }
  }
}
