import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { AuthService } from 'src/app/services/auth.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.page.html',
  styleUrls: ['./login.page.scss'],
})
export class LoginPage implements OnInit {

  constructor(public authservice:AuthService) { }
  email="harshadtibile@gmail.com";
  password="123456";
  ngOnInit() {
  }
  login()
  {
this.authservice.login(this.email,this.password).then((res:any)=>
  {
    console.log(res.user.uid);
  })
    console.log(this.email,this.password)
  }
}
