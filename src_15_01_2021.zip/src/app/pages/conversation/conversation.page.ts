import { Component, OnInit, ViewChild } from '@angular/core';
import { IonContent } from '@ionic/angular';
import { AuthService } from 'src/app/services/auth.service';

@Component({
  selector: 'app-conversation',
  templateUrl: './conversation.page.html',
  styleUrls: ['./conversation.page.scss'],
})
export class ConversationPage implements OnInit {
  newmsg='';
  @ViewChild(IonContent) content :IonContent;
  messages =
    [
      {
        user:'bot',
        createAt:'15012021',
        msg:'Hi'
      },
      {
        user:'Harsh',
        createAt:'15012021',
        msg:'Hello'
      },
      {
        user:'bot',
        createAt:'15012021',
        msg:'how are you'
      }
    ] ;
    
    constructor(public authservice:AuthService) { }
    
    ngOnInit() {
      console.log(this.messages)
    }
  sendmsg()
  {
this.messages.push(
  {
    user:'harsh',
    createAt:'15012021',
    msg:this.newmsg
  })
  this.newmsg='';
  setTimeout(() => {
    
    this.content.scrollToBottom(200);
  }, 500);
  }
  logout()
  {
    this.authservice.logout().then(res=>
      {
        console.log(res)
      });
  }
}
