import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { AlertController } from '@ionic/angular';
import { AngularFireAuth } from  "@angular/fire/auth";
import { ApiAiClient } from 'api-ai-javascript/es6/ApiAiClient'

import{environment} from '../../../environments/environment';
import { AuthService } from 'src/app/services/auth.service';
@Component({
  selector: 'app-register',
  templateUrl: './register.page.html',
  styleUrls: ['./register.page.scss'],
})
export class RegisterPage implements OnInit {
  name:string="Harsh";
  email:string="harsh@gmail.com";
  password:string="123456";
  confirm:string="123456";
  //readonly token = environment.dialogflow.angularBot;
  //readonly client = new ApiAiClient({ accessToken: this.token });

  constructor(public authservice:AuthService,public alertController: AlertController) { }

  ngOnInit() {
   // this.client.textRequest("text").then(res=>{console.log(res)})
  }
  register(form:NgForm)
  {
   console.log(form.form.value) 
   if(form.form.value!=='')
   {
this.authservice.register(this.email,this.password).then(res=>
  {
    console.log(res);
  })
     console.log(this.email) 
   }
  }
}
