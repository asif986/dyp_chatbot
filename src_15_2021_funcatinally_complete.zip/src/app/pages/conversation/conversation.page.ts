import { HttpClient } from '@angular/common/http';
import { Component, OnInit, ViewChild } from '@angular/core';
import { IonContent } from '@ionic/angular';
import { AuthService } from 'src/app/services/auth.service';

@Component({
  selector: 'app-conversation',
  templateUrl: './conversation.page.html',
  styleUrls: ['./conversation.page.scss'],
})
export class ConversationPage implements OnInit {
  newmsg='';
  @ViewChild(IonContent) content :IonContent;
  messages =[] ;
    
    constructor(public authservice:AuthService,public httpclient:HttpClient) { }
    
    ngOnInit() {
      console.log(this.messages)
      let body = 
{
  msg:"welcome"
}
console.log(body)
let currentDate=new Date();
    this.httpclient.post('http://localhost:5000/',body) .subscribe((data:any)=>
    {
      console.log(typeof(data))
      console.log(data.res)
      this.messages.push({
        user:'bot',
        createAt:currentDate.toDateString(),
        msg:data.res   
      });
      console.log(JSON.stringify(data))
    },error=>
    {
      console.log(error)
    })


    }


    sendmsg()
  {
let body = 
{
  msg:this.newmsg
}
console.log(body)
let currentDate=new Date();
    this.httpclient.post('http://localhost:5000/',body) .subscribe((data:any)=>
    {
      console.log(typeof(data))
      console.log(data.res)
      this.messages.push({
        user:'bot',
        createAt:currentDate.toDateString(),
        msg:data.res   
      });
      console.log(JSON.stringify(data))
    },error=>
    {
      console.log(error)
    })


this.messages.push(
  {
    user:'harsh',
    createAt:currentDate.toDateString(),
    msg:this.newmsg.trim()
  })
  this.newmsg='';
  setTimeout(() => {
    
    this.content.scrollToBottom(200);
  }, 500);
  }
  logout()
  {
    this.authservice.logout().then(res=>
      {
        console.log(res)
      });
  }
}
