import { Component, OnInit } from '@angular/core';
import { ApiAiClient } from 'api-ai-javascript';
@Component({
  selector: 'app-chat-dialog',
  templateUrl: './chat-dialog.component.html',
  styleUrls: ['./chat-dialog.component.scss'],
})
export class ChatDialogComponent implements OnInit {

  constructor() { }

  ngOnInit() 
  {
    
  }

}
