export const environment = {
  production: true,
  firebaseConfig : {
    apiKey: "AIzaSyAe3sQ-06-iLdmUqmVk1vH2--emWt_Uauo",
    authDomain: "college-chatbot-bfek.firebaseapp.com",
    projectId: "college-chatbot-bfek",
    storageBucket: "college-chatbot-bfek.appspot.com",
    messagingSenderId: "228684971887",
    appId: "1:228684971887:web:f9c7478ddaa5cf8f71f29a",
    measurementId: "G-BVP59NMY7L"
  }
};
