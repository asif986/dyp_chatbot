import { HttpClient } from '@angular/common/http';
import { Component, OnInit, ViewChild } from '@angular/core';
import { AlertController, IonContent, LoadingController } from '@ionic/angular';
import { AuthService } from 'src/app/services/auth.service';

@Component({
  selector: 'app-conversation',
  templateUrl: './conversation.page.html',
  styleUrls: ['./conversation.page.scss'],
})
export class ConversationPage implements OnInit {
  newmsg='';
  @ViewChild(IonContent) content :IonContent;
  messages =[] ;
    
    constructor(public authservice:AuthService,public httpclient:HttpClient,public loadingctr:LoadingController,public alterctrl:AlertController) { }
    
    ngOnInit() {
      console.log(this.messages)
      let body = 
{
  msg:"welcome"
}
console.log(body)
let currentDate=new Date();
    this.httpclient.post('http://localhost:5000/',body) .subscribe((data:any)=>
    {
      console.log(typeof(data))
      console.log(data.res)
      this.messages.push({
        user:'bot',
        createAt:new Date(),
        msg:data.res   
      });
      console.log(JSON.stringify(data))
    },error=>
    {
      console.log(error)
    })


    }


    sendmsg()
  {
let body = 
{
  msg:this.newmsg
}
console.log(body)
let currentDate=new Date();
    this.httpclient.post('http://localhost:5000/',body) .subscribe((data:any)=>
    {
      console.log(typeof(data))
      console.log(data.res)
      this.messages.push({
        user:'bot',
        createAt:new Date(),
        msg:data.res   
      });
      console.log(JSON.stringify(data))
    },error=>
    {
      console.log(error)
    })


this.messages.push(
  {
    user:'harsh',
    createAt:new Date(),
    msg:this.newmsg.trim()
  })
  this.newmsg='';
  setTimeout(() => {
    
    this.content.scrollToBottom(200);
  }, 500);
  }
  async logout()
  {
    const loading = await this.loadingctr.create({message:"Please wait..",duration:2000});
const alert = await this.alterctrl.create({message:"Thank you for using Our DYPChatBot!!!",buttons:[{text:"Ok",role:'Ok'}]})
 
    loading.present();
    await this.authservice.logout().then(res=>
      {
        console.log(res)
        setTimeout(() => {
          
          loading.dismiss()
          alert.present();
        }, 2000);
      });
  }
}
